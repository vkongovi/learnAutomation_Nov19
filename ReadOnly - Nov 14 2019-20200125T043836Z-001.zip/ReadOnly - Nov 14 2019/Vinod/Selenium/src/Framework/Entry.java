package Framework;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.seleniumhq.jetty9.util.log.Log;
import org.seleniumhq.jetty9.util.log.Logger;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Entry extends ReusableMethods {


    public static void main(String[] args) throws InterruptedException, IOException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {

        InitializeReport();
        InitializeDriver();
//        Method testCase = SalesForceTestCases.class.getMethod("TC2_LoginSalesForce");
//        String[][] data = readXlData("C:\\Users\\Vinod TA\\Google Drive\\1. TATrainingAndPlacements\\QA Automation\\QA Automation 2019\\Nov 14 2019\\ReadOnly - Nov 14 2019\\SeleniumUtilityFiles\\TC1_LoginSalesForce.xls","Sheet1");
//        testCase.invoke(testCase,data);
        // Java Reflections
        //SeleniumDemo.class.getMethod()

        TC2_LoginSalesForce();
        TC2_LoginError();
        reports.flush();
    }

    public static void TC2_LoginError() throws InterruptedException, IOException {
        logger = reports.startTest("Login With Error");

        String[][] data = readXlData("C:\\Users\\Vinod TA\\Google Drive\\1. TATrainingAndPlacements\\QA Automation\\QA Automation 2019\\Nov 14 2019\\ReadOnly - Nov 14 2019\\SeleniumUtilityFiles\\TC1_LoginSalesForce.xls","Sheet1");

//        driver.get("https://login.salesforce.com/");
        driver.get(data[0][1]);
        WebElement uName = driver.findElement(By.xpath("//input[@id='username']"));
        enterText(uName, data[1][1], "UserName");
        WebElement pWord = driver.findElement(By.xpath("//input[@id='password']"));
        enterText(pWord, "", "Password");
        WebElement loginBtn = driver.findElement(By.xpath("//input[@id='Login']"));
        clickElement(loginBtn, " Login Button");
        logger.log(LogStatus.INFO,  "MEssage 1");
        logger.log(LogStatus.INFO,  "Message 23y");

        WebElement error = driver.findElement(By.id("error"));
        if(error.getText().equals("Please enter your password."))
        {
            logger.log(LogStatus.PASS, "Error message displayed succesfully");
        }
        else{
            logger.log(LogStatus.FAIL, " Error message is not displayed.");
        }

//        writeXlData(reportExcelFile, "Report",0,0, "Success123");

        Thread.sleep(10000);
        reports.endTest(logger);

        //driver.close();
    }

    public static void TC2_LoginSalesForce() throws InterruptedException, IOException {

        logger = reports.startTest("Login");
        logger.log(LogStatus.INFO, " Test case Started");

        String[][] data = readXlData("C:\\Users\\Vinod TA\\Google Drive\\1. TATrainingAndPlacements\\QA Automation\\QA Automation 2019\\Nov 14 2019\\ReadOnly - Nov 14 2019\\SeleniumUtilityFiles\\TC1_LoginSalesForce.xls","Sheet1");

//        driver.get("https://login.salesforce.com/");
        driver.get(data[0][1]);
        WebElement uName = driver.findElement(By.xpath("//input[@id='username']"));
        enterText(uName, data[1][1], "UserName");
        logger.log(LogStatus.INFO,  "Username is entered successfully");
        WebElement pWord = driver.findElement(By.xpath("//input[@id='password']"));
        enterText(pWord, data[2][1], "Password");
        logger.log(LogStatus.INFO,  "Password is entered successfully");
        WebElement loginBtn = driver.findElement(By.xpath("//input[@id='Login']"));
        clickElement(loginBtn, " Login Button");
        logger.log(LogStatus.ERROR,  "Login Button Clicked successfully");

//        writeXlData(reportExcelFile, "Report",0,0, "Success123");

        Thread.sleep(5000);
        logger.log(LogStatus.FAIL, "TC failed and see the attached screenshot. \r\n" + logger.addScreenCapture(takeScreenshot()));

        reports.endTest(logger);
       // driver.close();
    }



}
