package Framework;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.io.IOException;

public class SalesForceTestCases extends  ReusableMethods{


}
