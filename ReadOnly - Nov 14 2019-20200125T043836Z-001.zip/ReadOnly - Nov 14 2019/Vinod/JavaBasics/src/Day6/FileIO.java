package Day6;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileIO {
    public static void main(String[] args) {

        try {
            FileReader reader = new FileReader("C:\\Users\\Vinod TA\\Google Drive\\1. TATrainingAndPlacements\\QA Automation\\QA Automation 2019\\Nov 14 2019\\ReadOnly - Nov 14 2019\\Vinod\\JavaBasics\\MyFile.txt");
            BufferedReader bufferedReader = new BufferedReader(reader);
            String line;
            while((line = bufferedReader.readLine()) != null){
                System.out.println(line);
            }
            reader.close();
        }
        catch (IOException e){
            System.out.println(e.getMessage());
        }

        try {
            FileWriter writer = new FileWriter("C:\\Users\\Vinod TA\\Google Drive\\1. TATrainingAndPlacements\\QA Automation\\QA Automation 2019\\Nov 14 2019\\ReadOnly - Nov 14 2019\\Vinod\\JavaBasics\\MyFile_new.txt", true);
            writer.write("Hello World");
            writer.write("\r\n");   // write new line
            writer.write("Good Bye!");
            writer.close();
        }
        catch (IOException e){
            System.out.println(e.getMessage());
        }
    }
}
