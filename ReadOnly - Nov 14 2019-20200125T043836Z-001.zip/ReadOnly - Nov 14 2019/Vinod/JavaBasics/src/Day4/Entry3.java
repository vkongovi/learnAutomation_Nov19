package Day4;

// REcursive methods

public class Entry3 {
    public static void main(String[] args) {
        System.out.println("Factorial of 5 is " + Factorial(5));
    }

    public static int Factorial(int x){
        int retVal = 1;

        // 5 factorial = 5 * 4 *3 *2 *1
//        for(int i = x; i>=1; i--){
//            retVal = retVal * i;
//        }
        if(x>1){
            return x * Factorial(x-1);
        }
        return retVal;
    }


}
