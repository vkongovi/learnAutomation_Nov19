package Day4;

public class Dog extends Animal {



    // Dog has decided to override the Move method from its parent.
    public void Move(int speed){
        super.Move(speed);
        System.out.println("I am the Move method from Dog Class");
        age = age + 10;
    }
}
