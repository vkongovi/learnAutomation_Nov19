package Day4;

public class Entry {
    public static void main(String[] args) {
        int a = 10;
        int[] ages = {2,34,38,23};

        // length
        // hoe to get individual items
        int index =  10;
        if(index < ages.length )
        {
            int x = ages[index];
        }
        // foreach
        for(int j : ages){
            System.out.println(j);
        }
    }
}
