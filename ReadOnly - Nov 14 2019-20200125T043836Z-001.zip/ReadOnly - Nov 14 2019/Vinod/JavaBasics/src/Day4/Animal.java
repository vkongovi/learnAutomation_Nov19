package Day4;

public class Animal {

    String name;
    int age = 10;

    public void Move(int speed){
        System.out.println("I am the Move method from Animal Class");
        age = age + 1;
    }
}
