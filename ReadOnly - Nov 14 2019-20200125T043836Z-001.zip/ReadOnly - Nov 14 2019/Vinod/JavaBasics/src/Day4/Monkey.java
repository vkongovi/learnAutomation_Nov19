package Day4;

public class Monkey {
    protected int age;
}
