package Day4;

public class Entry4 {
    public static void main(String[] args) {
        // Exceptions

        int[] ages  =  {23,34,56,45,24};
        float x = 0;
        try{
            //x =  Divide(3,Divide(3,0));
            x=ages[10];
        }
        catch(NumberFormatException ex){
            System.out.println("Please check your number and try again");
        }
        catch(IndexOutOfBoundsException ex){
            System.out.println("Please check your file size...." + ex.getMessage());
        }
        catch(Exception ex){
            System.out.println("Something went wrong. Please try again");
        }
        finally{
            System.out.println("Finally called");
        }
        System.out.println("Value of x is " + x);
    }

    static float Divide(float a, float b){
        return a/b;
    }
}
