package Day4;

public class Entry2 {

    public static void main(String[] args) {
        // Polymorphism => dynamic and static
        System.out.println(Add(2,3));
        System.out.println(Add(2,3,5));

        Animal a1 = new Animal();
        Dog d1 = new Dog();


//        a1.Move(10);
//        d1.Move(20);

        Method1(a1);
        Method1(d1);

//        Method2(a1);
        Method2(d1);
    }

    public static void  Method1(Animal a){
        System.out.println("Method 1 is called" );
        a.Move(20);
    }

    public static void Method2(Dog d){
        System.out.println("Method 2 is called");
    }

    // method overloading
    // static polymorphism. Compiler will decide which function to call.
    public static int Add(int x, int y){
        return x+y;
    }

    public static int Add(int x, int y, int z){
        return x+y+z;
    }
}
