package Day5;

public class Rectangle extends Shape{

    Rectangle(String name) {
        super(name);
    }

    @Override
    public int draw() {
        objectName = "ABC";
        return 1;
    }


}
