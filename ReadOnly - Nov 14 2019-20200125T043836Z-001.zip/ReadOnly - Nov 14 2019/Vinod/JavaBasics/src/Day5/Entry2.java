package Day5;

// Abstract Classes
// Interfaces
public class Entry2 {
    public static void main(String[] args) {

       // Shape s1 = new Shape("Square");
        Rectangle r1 = new Rectangle("ABC");
        r1.moveTo(3,4);
    }
}
