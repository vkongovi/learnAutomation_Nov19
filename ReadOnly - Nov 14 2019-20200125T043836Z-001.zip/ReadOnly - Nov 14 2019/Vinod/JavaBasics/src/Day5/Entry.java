package Day5;

// String
// What is String immutability
// String Builder = is not thread safe + This is faster
// String Buffers = is thread safe + This is slower in operation
// Abstract classes
        // Abstract class can have abstract and non-abstract methods.
        // Abstract class doesn't support multiple inheritance.
        // Abstract class can have final, non-final, static and non-static variables.
// Interfaces
        //Interface can have only abstract methods. Since Java 8, it can have default and static methods also.
        //Interface supports multiple inheritance.
        //Interface has only static and final variables.

public class Entry {
    public static void main(String[] args) {
        String S1 = "Vinod";
        StringBuilder s2 = new StringBuilder("Vinod");
        StringBuffer s3 = new StringBuffer("Vinod");
        s2.toString();
        s3.toString();
        s2 = new StringBuilder(S1);

        concat1(S1);
        System.out.println("String: "+ S1);

        concat2(s2);
        System.out.println("String: "+ s2);

        concat3(s3);
        System.out.println("String: "+ s3);
    }

    public static void concat1(String s1){
        s1 = s1 + " Kumar";
    }

    public static void concat2(StringBuilder s2){
        s2 = s2.append(" Kumar");
    }

    public static void concat3(StringBuffer s2){
        s2 = s2.append(" Kumar");
    }



}
