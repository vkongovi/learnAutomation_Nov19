package Day5_2;

public class Entry {
    public static void main(String[] args) {

    }
}
