package Day5_2;

public interface Design {

    void fillColor();
}
