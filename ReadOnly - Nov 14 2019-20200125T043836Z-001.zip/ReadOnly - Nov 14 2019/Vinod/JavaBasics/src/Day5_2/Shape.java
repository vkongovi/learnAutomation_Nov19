package Day5_2;

public interface Shape {

    int i = 20;
    void draw();
    double area();

    void moveTo(int x, int y);
}
