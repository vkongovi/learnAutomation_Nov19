package Day5_2;

public class Rectangle implements Shape, Design{


    @Override
    public void draw() {

        //i = 30;
    }

    @Override
    public double area() {
        return 0;
    }

    @Override
    public void moveTo(int x, int y) {

    }

    @Override
    public void fillColor() {

    }
}
