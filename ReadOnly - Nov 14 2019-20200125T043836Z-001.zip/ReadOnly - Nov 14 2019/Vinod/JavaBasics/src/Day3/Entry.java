package Day3;

public class Entry {
    public static void main(String[] args) {
        int x = 10;
        Car c1 = new Car();
        c1.engineCapacity =  10;
        Car c2 = new Car();
        c2.engineCapacity =  15;

        System.out.println("Before Value of x is " + x);
        System.out.println("Before Value of engineCapacity is " + c1.engineCapacity);
        System.out.println("Before Value of engineCapacity is " + c2.engineCapacity);

        Method1(x);
        Method2(c1);
        Method2(c2);

        System.out.println("After Value of x is " + x);
        System.out.println("After Value of engineCapacity is " + c1.engineCapacity);
        System.out.println("Before Value of engineCapacity is " + c2.engineCapacity);

    }


    public static void Method1(int a){
        a = 20;
    }

    public static void Method2(Car c){
        c.engineCapacity = 20;
    }

}
