package Day3;

import Day4.Monkey;

public class M2 extends Monkey {

    void Method1(){
        age =age + 10;
    }
}
