package Day3;

public class Animal {
    String bread;
    String color;

    public void AnimalMethod(){

    }
}
