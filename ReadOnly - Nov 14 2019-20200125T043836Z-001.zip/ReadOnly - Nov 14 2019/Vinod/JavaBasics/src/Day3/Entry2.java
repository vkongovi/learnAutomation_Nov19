package Day3;

import java.util.ArrayList;

public class Entry2 {
    public static void main(String[] args) {
        // boxing and un boxing
        // int, float, double, short, byte, boolean
        int i = 1;
        Integer j = 0;
        double f1 = 0;
        Double f2 =  0.0;
        float f3 = 0;
        Float f4 = f3;
        float x = f4;

        ArrayList<Integer> l1  = new ArrayList<>();
//        ArrayList<int> l2  = new ArrayList<>();


    }
}
