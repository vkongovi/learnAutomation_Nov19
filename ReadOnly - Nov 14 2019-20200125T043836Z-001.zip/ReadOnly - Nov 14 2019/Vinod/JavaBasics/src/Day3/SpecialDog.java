package Day3;

public class SpecialDog extends Dog {
    int height;

    public void sdMethod(){

    }
}
