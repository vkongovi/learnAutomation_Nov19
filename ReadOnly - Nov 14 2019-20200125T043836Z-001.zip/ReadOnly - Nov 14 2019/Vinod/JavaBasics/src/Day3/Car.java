package Day3;

public class Car {
    int engineCapacity;
    String brand;
    int yearOfMfg;

}
