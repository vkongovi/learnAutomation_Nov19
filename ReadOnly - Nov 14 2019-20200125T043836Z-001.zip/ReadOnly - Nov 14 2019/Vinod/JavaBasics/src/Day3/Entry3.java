package Day3;

// OOPs => Object Oriented Programming
// Encapsulation =>
public class Entry3 {
    public static void main(String[] args) {


        int c1EngineCapacity = 1000;
        String c1Brand = "Audi";
        int c1YearOfMfg = 2010;

        int c2EngineCapacity = 2000;
        String c2Brand = "BMW";
        int c2YearOfMfg = 2010;

        Car c1 = new Car();
        Car c2 = new Car();

        c1.engineCapacity = 1000;
        c1.brand = "Audi";
        c1.yearOfMfg = 2010;

        c2.engineCapacity = 2000;
        c2.brand = "BMW";
        c2.yearOfMfg  = 2010;

    }
}
