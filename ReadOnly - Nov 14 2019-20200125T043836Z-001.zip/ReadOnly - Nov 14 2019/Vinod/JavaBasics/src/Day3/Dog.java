package Day3;

public class Dog extends Animal{
    String age;
    String name;

    public void DogMenthod(){

    }
}
