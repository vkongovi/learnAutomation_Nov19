package Day2;

public class Entry {

    // for + while + dowhile + foreach
    public static void main(String[] args) {
        System.out.println("Begin");
        // initializing , validation , increment
        for (int i = 4; i < 100; i = i + 6) {
//            System.out.println("Value of i is " + i);
        }

        int i = 4;
        while(i<100){

//            System.out.println("While loop == Value of i is " + i);
            i = i + 6;
        }

        // do while loop
        i = 400;
        do{
//            System.out.println("Do While loop == Value of i is " + i);
            i = i + 6;
        }while (i<100);

        // for each loop
        // Collections arrays
        int[] ageList = {2,3,5,9,3};
        for(int age :ageList){
            System.out.println("Age = " + age);
        }

    }

}
