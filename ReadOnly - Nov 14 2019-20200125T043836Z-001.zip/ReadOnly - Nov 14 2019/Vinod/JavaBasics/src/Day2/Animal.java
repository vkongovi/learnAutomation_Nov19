package Day2;

public class Animal {

    final String breed = "Dog";

    // Global variable
    String name;

    public void Method1(){
        // breed = "parrot";
        // local variable
        int age = 0;
        name = name + "abc";
        age = age + 30;

    }

    public void Method2(){
        name = name + "xyZ";
        //age = age + 50;
    }
}
