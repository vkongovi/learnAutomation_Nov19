package Day2;

public class Entry5 {
    public static void main(String[] args) {

        int i = 110;
        String s = "Sasdfas";

        System.out.println( s.length());
        System.out.println( s.charAt(3));



    }
}
