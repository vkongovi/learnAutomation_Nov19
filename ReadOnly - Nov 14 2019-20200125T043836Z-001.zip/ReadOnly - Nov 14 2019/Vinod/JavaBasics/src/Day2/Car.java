package Day2;

public class Car {
    String fuelType;
    static String brand;

    public void Method1(){

    }

    public static void Method2(){

    }
}
