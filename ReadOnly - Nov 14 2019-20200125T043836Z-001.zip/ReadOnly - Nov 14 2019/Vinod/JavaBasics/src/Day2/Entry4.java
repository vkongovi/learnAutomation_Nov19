package Day2;

public class Entry4 {



    public static void main(String[] args) {

    }
}
