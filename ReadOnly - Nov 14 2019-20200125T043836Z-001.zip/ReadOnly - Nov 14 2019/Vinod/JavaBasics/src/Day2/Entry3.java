package Day2;

public class Entry3 {
    // static methonds can call only another static methods
    // static methods cannot call non static methods
    // static methods can use local variables and static variable
    // static methods cannot use not static variables

    static String s1 = "123";
    static String s2 = "abc";

    public static void main(String[] args) {
        xyzMethod();
        s2 = s2 +"asdfasd";
        s1 = s1 + "asdfas";
    }

    public static void xyzMethod(){
        s2 = s2 +"asdfasd";
        s1 = s1 + "asdfas";
    }
}
