package Day2;

// Static and Non Static
public class Entry2 {
    public static void main(String[] args) {
        System.out.println("Begin");

        Car c1 = new Car();
        Car c2 = new Car();
        Car c3 = new Car();
        c1.fuelType = "Petrol";
        c1.brand = "VW";
        c2.fuelType = "Diesel";
        c2.brand = "BMW";
        c3.fuelType = "Petrol";
        c3.brand = "Audi";

        System.out.println("C1 details : Fuel =" + c1.fuelType + " Brand =" + c1.brand);
        System.out.println("C2 details : Fuel =" + c2.fuelType + " Brand =" + c2.brand);
        System.out.println("C3 details : Fuel =" + c3.fuelType + " Brand =" + c3.brand);

        Car c4 = new Car();
        c4.fuelType = "xyz";
        c4.brand = "Benz";

        Car.brand = "Benz";

        c3.Method1();
        c3.Method2();

        Car.Method2();


    }

    public void XYZMethod(){

    }
}
