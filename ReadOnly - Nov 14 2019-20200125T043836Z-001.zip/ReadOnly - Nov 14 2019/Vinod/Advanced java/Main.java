package com.company;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Main {

    public static void main(String[] args) {
	// write your code here
        List<List<String>> items = new ArrayList<>();
        ArrayList<String> item1 = new ArrayList<>();
        ArrayList<String> item2 = new ArrayList<>();
        ArrayList<String> item3 = new ArrayList<>();
        ArrayList<String> item4 = new ArrayList<>();

        item1.add("owjevtkuyv");
        item1.add("12");
        item1.add("24");

        item2.add("rpaqgbjxik");
        item2.add("35");
        item2.add("6");

        item3.add("dfbkasyqcn");
        item3.add("19");
        item3.add("42");

        item4.add("vjrrisdfxe");
        item4.add("32");
        item4.add("88");

        items.add(item1);
        items.add(item2);
        items.add(item3);
        items.add(item4);

        fetchItemsToDisplay( items,0,0,2,0);

    }

    public static List<String> fetchItemsToDisplay(List<List<String>> items, int sortParameter, int  sortOrder, int itemPerPage, int pageNumber){
        List<String> result = new ArrayList<>();
        ArrayList<Item> ar = new ArrayList<Item>();
        for (List<String> i : items){
            ar.add(new Item(i.get(0),Integer.parseInt(i.get(1)), Integer.parseInt(i.get(2)), sortParameter,sortOrder));
        }

        for (int i=0; i<ar.size(); i++) {
            System.out.println(ar.get(i));
        }

        Collections.sort(ar, new Sortby());

        System.out.println("Sorted");
        for (int i=0; i<ar.size(); i++) {
            System.out.println(ar.get(i));
        }
        for (int i=itemPerPage*pageNumber; i<ar.size() && result.size()<itemPerPage;i++){
            result.add(ar.get(i).name);
//            System.out.println(ar.get(i).name);
        }
        return result;
    }
}

class Item
{
    String name;
    int relevance, price, sortBy, order;
    // Constructor
    public Item(String name, int relevance,int price, int sortBy, int order)
    {
        this.name = name;
        this.relevance = relevance;
        this.price = price;
        this.sortBy = sortBy;
        this.order = order;
    }
    // Used to print student details in main()
    public String toString()
    {
        return this.name + " " + this.relevance + " " + this.price;
    }
}

class Sortby implements Comparator<Item>
{
    // Used for sorting in ascending order of
    // roll number
    public int compare(Item a, Item b)
    {
        int retVal = 0;
        if(a.sortBy == 0)
            retVal = a.name.compareTo(b.name);
        else if (a.sortBy == 1)
            retVal = a.relevance - b.relevance ;
        else
            retVal =  a.price - b.price ;

        // decending
        return a.order==0?retVal:retVal*-1;
//        if (a.order==0)
//            return retVal;
//        else
//            return retVal*-1;
    }
}


