
public class Student implements Comparable<Student>{

	public String name;
	public int Id;
	
	Student(String name, int Id){
		this.name = name;
		this.Id = Id;
	}

	@Override
	public int compareTo(Student o) {
		// return 0 means both are equal
		// -ve means this is bigger
		// +ve means the input is bigger
		// return this.Id - o.Id;
		System.out.println("Comparing " + this.name + " to "+ o.name);
		return this.name.compareTo(o.name);
	}
}
