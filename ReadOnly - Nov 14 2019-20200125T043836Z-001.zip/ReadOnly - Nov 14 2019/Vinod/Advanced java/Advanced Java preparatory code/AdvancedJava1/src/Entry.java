import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;

/*
 * Collection Framework
 * List
 * Queue = Ignore
 * Set
 * Map
 * 
 * 
 * 
 * Collection = Top level Interface
 * Collections = Utility class
 */


public class Entry {

	public static void main(String[] args) {
		
		//int[] intArray = {2,3,4};
		LinkedList<Integer> intList = new LinkedList<>();
		intList.add(3);
		intList.add(3);
		intList.add(2);
		//intList.add(null);
		//intList.add(null);
		intList.add(44);
		intList.add(3);
		intList.add(7);
		intList.remove(4);
		int b = 34;
		intList.add(2, b);
		intList.set(4, 66);
		
		
		LinkedList<Integer> list2 = new LinkedList<>();
		list2.add(4);
		list2.addAll(intList);
		
		
		//System.out.println(intList);
		
		
		Iterator<Integer> it = intList.iterator();
//		while(it.hasNext()) {
//			System.out.println("1. content is: " + it.next());
//		}
		
		
		Collections.sort(intList);
		Iterator<Integer> it2 = intList.iterator();
//		while(it2.hasNext()) {
//			System.out.println("2. content is: " + it2.next());
//		}
		
		LinkedList<Student> studentList = new LinkedList<>();
		studentList.add(new Student("Arnish", 1));
		studentList.add(new Student("Meenakshi", 4));
		studentList.add(new Student("Priyanka", 3));
		studentList.add(new Student("Kavitha", 2));
		
		Iterator<Student> it3 = studentList.iterator();
		while(it3.hasNext()) {
			Student tempStudent = it3.next();
			//System.out.println("1. Student: " + tempStudent.Id + " name is " + tempStudent.name);
		}
		
		Collections.sort(studentList);
		
		Iterator<Student> it4 = studentList.iterator();
		while(it4.hasNext()) {
			Student tempStudent = it4.next();
			System.out.println("2. Student: " + tempStudent.Id + " name is " + tempStudent.name);
		}
	}

}
