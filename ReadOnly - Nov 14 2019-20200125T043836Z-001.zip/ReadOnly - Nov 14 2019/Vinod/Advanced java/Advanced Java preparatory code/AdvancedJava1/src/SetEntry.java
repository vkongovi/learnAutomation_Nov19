import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.TreeSet;

public class SetEntry {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//HashSet<Integer> hs = new HashSet<>();
//		LinkedHashSet<Integer> hs = new LinkedHashSet<>();
		TreeSet<Integer> hs = new TreeSet<>();
		hs.add(2);
		hs.add(5);
		hs.add(8);
		hs.add(3);
		hs.add(22);
		hs.add(22);
		hs.add(6);
		
		
		System.out.println(hs);
	}

}
