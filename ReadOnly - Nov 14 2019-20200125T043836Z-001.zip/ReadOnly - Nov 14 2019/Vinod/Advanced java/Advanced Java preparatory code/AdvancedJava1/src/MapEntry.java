import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class MapEntry {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Queue<String> q = new LinkedList<String>();
		
		q.add("vinod"); // poll
		q.add("Neha");
		q.add("swetha");
		q.add("anand");
		q.add("Anthony");
		
		int qSize = q.size();
		for(int i=0; i<qSize ; i++) {
			System.out.println(q.poll());
			System.out.println(q.peek());
			
			
			System.out.println(q.size());
		}
		
		
		System.out.println(" ===========Stacks========== ");
		
		Stack<String> names = new Stack<>();
		names.push("vinod");
		names.push("Neha");
		names.push("swetha");
		names.push("anand");
		names.push("Anthony");
		
		names.forEach(n -> {
			//System.out.println(n);
		});
		
		int stackSize = names.size();
		for(int i=0; i<stackSize ; i++) {
			System.out.println(names.pop());
			//System.out.println(names.peek());
			System.out.println(names.size());
		}

	}

}
