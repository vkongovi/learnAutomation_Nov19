import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

import java.io.IOException;
import java.sql.Driver;

/*
 Testing Suites
 Parallel Testing
 Cross Browser Testing
 Reports

 Maven
 */

public class FirstTestCase {

    protected static WebDriver driver;

    @BeforeClass
    void BeforeClassMethod(){


    }

    @AfterClass
    void AfterClassMethod(){
        System.out.println("AfterClassMethod");
    }


    @AfterMethod
    void LogMessage(){
        System.out.println("LogMessage");

    }

    @BeforeMethod
    void BeforeMessage(){
        System.out.println("BeforeMessage");
    }

    @Test
    void TestCase1() throws IOException, InterruptedException {
        System.setProperty("webdriver.chrome.driver","C:\\Users\\Vinod TA\\Google Drive\\1. TATrainingAndPlacements\\QA Automation\\QA Automation 2019\\Nov 14 2019\\ReadOnly - Nov 14 2019\\SeleniumUtilityFiles\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        System.out.println("TC1");
        driver.get("https://login.salesforce.com/");
        WebElement uName = driver.findElement(By.xpath("//input[@id='username']"));
        enterText(uName, "Mithun.r@tekarch.com", "UserName");
        WebElement pWord = driver.findElement(By.xpath("//input[@id='password']"));
        enterText(pWord, "Test1234", "Password");
        WebElement loginBtn = driver.findElement(By.xpath("//input[@id='Login']"));
        clickElement(loginBtn, " Login Button");

        Thread.sleep(10000);
//        Assert.assertEquals(5,10);
    }

    @Test ( description = "This will Login into SFDC")
    void LoginSFDC() throws InterruptedException, IOException {
        System.setProperty("webdriver.chrome.driver","C:\\Users\\Vinod TA\\Google Drive\\1. TATrainingAndPlacements\\QA Automation\\QA Automation 2019\\Nov 14 2019\\ReadOnly - Nov 14 2019\\SeleniumUtilityFiles\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://login.salesforce.com/");
        WebElement uName = driver.findElement(By.xpath("//input[@id='username']"));
        enterText(uName, "Mithun.r@tekarch.com", "UserName");
        WebElement pWord = driver.findElement(By.xpath("//input[@id='password']"));
        enterText(pWord, "Test1234", "Password");
        WebElement loginBtn = driver.findElement(By.xpath("//input[@id='Login']"));
        clickElement(loginBtn, " Login Button");


        Thread.sleep(10000);

        //driver.close();
//        System.out.println("LoginSFDC");
//        SimpleFunction();
////        WebDriver d = new ChromeDriver();
////        WebElement  userName = d.findElement(By.xpath("asfasdf"));
//        Object userName = new Object();
//        //Assert.assertNotNull(userName);
//        Assert.assertNotEquals(userName,"vinod");
    }

    @Test
    void AccountsSFDC() throws IOException, InterruptedException {
        System.out.println("AccountsSFDC");
        System.setProperty("webdriver.chrome.driver","C:\\Users\\Vinod TA\\Google Drive\\1. TATrainingAndPlacements\\QA Automation\\QA Automation 2019\\Nov 14 2019\\ReadOnly - Nov 14 2019\\SeleniumUtilityFiles\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();

        driver.get("https://login.salesforce.com/");
        WebElement uName = driver.findElement(By.xpath("//input[@id='username']"));
        enterText(uName, "Mithun.r@tekarch.com", "UserName");
        WebElement pWord = driver.findElement(By.xpath("//input[@id='password']"));
        enterText(pWord, "Test1234", "Password");
        WebElement loginBtn = driver.findElement(By.xpath("//input[@id='Login']"));
        clickElement(loginBtn, " Login Button");

        Thread.sleep(10000);
//        SimpleFunction();
    }

    public static void enterText(WebElement ele, String txtValue, String objectName){
        if(ele.isDisplayed()){
            ele.sendKeys(txtValue);
            System.out.println(txtValue + "has been successfully Entered  into " + objectName);
        }
        else{
            System.out.println(objectName + " is not displayed on the web page.");
        }
    }

    public static void clickElement(WebElement ele, String ObjectName) throws IOException {
        if(ele.isDisplayed())
        {
            ele.click();;
            System.out.println(ObjectName + " has been successfully clicked");
        }
        else
        {
            System.out.println(ObjectName + " is not displayed in the web page.");
        }
    }


    void SimpleFunction(){
        System.out.println("Simple method");
    }
}
