package Pack1;

import org.testng.annotations.Test;

public class Login {
    @Test
    void  LoginSFDC(){

    }

    @Test
    void LogOut(){

    }
}
