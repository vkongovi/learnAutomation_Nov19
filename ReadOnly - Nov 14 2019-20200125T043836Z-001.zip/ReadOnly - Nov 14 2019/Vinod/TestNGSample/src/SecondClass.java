import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class SecondClass {

    @Test
    void Login() {
        System.out.println("Login TC");

    }

    @Test
    @Parameters ("size")
    void Logout(String size) {
        if(size.equals("2")){
            System.out.println("Size is 2");
        }
        else
        {
            System.out.println("Size is not 2");
        }
        System.out.println("Log out method");
    }
}
