// import { element } from "protractor";

// browser == driver
// all concepts  you learnt in Selenium will be true here also
// element == driver.findelement 
// element.all() == driver.findlelements
// expect == Assert
/* 
1. model = 
2. repeator
3. option
4. binding = 
5. partialButtontext => 
6. buttontext =>
7. id =>
8. classname =>
9. xpath =>
10. css = >
11. linktext =>
12. partiallinktext =>
13. tagname  => 
14. name => 

*/

// binding => {{varName}}

// find the wenelement
// perform some action on it
// verify


describe('MyTestSuite', function(){
    it('Test Case1', function(){
        browser.get('http://www.way2automation.com/angularjs-protractor/calc/');
        browser.manage().window().maximize();

        browser.sleep(2000);

        var first = element(by.model('first'));

        console.log('111')
        element.all(by.options('value for (key, value) in operators')).then(function(a) {
            a[2].click();
            console.log('222');
        });
        console.log('333');
        var second = element(by.model('second'));
        var btn =  element(by.partialButtonText('Go'));

        // elements.all()

        var result = element(by.binding('latest'));

        first.sendKeys(3);
        second.sendKeys(6);
        btn.click();

        expect(result.getText()).toBe('9');
        browser.sleep(5000);
    });

    it('Subraction',function(){

    });
});