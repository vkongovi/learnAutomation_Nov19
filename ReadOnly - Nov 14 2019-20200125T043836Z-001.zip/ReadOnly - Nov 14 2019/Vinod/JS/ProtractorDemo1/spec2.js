var data =  require('./utility/data.json');
const logger;
function calculate(aValue, bValue, optIndex) {
    var first = element(by.model('first'));
    var second = element(by.model('second'));
    var btn = element(by.partialButtonText('Go'));

    first.sendKeys(aValue);
    second.sendKeys(bValue);
    element.all(by.options('value for (key, value) in operators')).then(function (a) {
        a[optIndex].click();
        btn.click();
    });
};

describe('MyTestSuite', function () {
    // once for this describe
    beforeAll(function(){
        logger = winston.createLogger({
            level: 'info',
            format: winston.format.json(),
            transports: [
              //
              // - Write to all logs with level `info` and below to `combined.log` 
              // - Write all logs error (and below) to `error.log`.
              //
              new winston.transports.File({ filename: './log/error.log', level: 'error' }),
              new winston.transports.File({ filename: 'combined.log' })
            ]
          });

    });

    afterAll(function(){

    });

    // this is for every it block
    beforeEach(function () {
        browser.get(data.url);
        browser.manage().window().maximize();
        browser.sleep(1000);
    });

    afterEach(function () {
        console.log('TestCase Completed');
        logger.log('debug','TestCase Completed')
    });

    it('Addition ', function () {
        calculate(data.add.a,data.add.b,0);
        var result = element(by.binding('latest'));
        expect(result.getText()).toBe(data.add.result);
        browser.sleep(3000);
    });

    it('Subraction', function () {
        calculate(6,2,4);
        var result = element(by.binding('latest'));
        expect(result.getText()).toBe('4');
        browser.sleep(3000);
    });
});