// An example configuration file.
exports.config = {
  //directConnect: true,
  seleniumAddress: 'http://localhost:4444/wd/hub',

  // Capabilities to be passed to the webdriver instance.
  /*capabilities: {
    'browserName': 'chrome'
  },*/

  // parallel testing
  capabilities : {
		browserName : 'chrome',
		shardTestFiles : true,
		maxInstances : 3,
	},


 // Multi browser testing
  // multiCapabilities: [
  //   {
  //     'browserName': 'chrome',
  //     specs: ['./src/FunctionalTests/Calculator.js'],
  //   },
  //   {
  //     'browserName': 'firefox',
  //     specs: ['./src/Regression/example_spec.js'],
  //   }
  // ],

  // Framework to use. Jasmine is recommended.
  framework: 'jasmine',

  // Spec patterns are relative to the current working directory when
  // protractor is called.
  //specs: ['spec2.js','spec3.js','spec4.js'],
  //specs: ['spec2.js'],
  specs: ['spec6.js','spec4.js','spec9.js'],

  // suites: {
  //   functional: ['spec2.js', 'spec3.js', 'spec4.js'],
  //   regression: ['spec2.js'],
  //   exampleTS: ['spec6.js', 'spec4.js', 'spec9.js']
  // }, // protractor conf.js --suite regression,exampleTS

  onPrepare: function () {
    browser.ignoreSyncronization = false;
  },

  // Options to be passed to Jasmine.
  jasmineNodeOpts: {
    defaultTimeoutInterval: 30000
  }
};
