console.log('Hi. I am Vinod')
var catMe = require('cat-me');

console.log(catMe());