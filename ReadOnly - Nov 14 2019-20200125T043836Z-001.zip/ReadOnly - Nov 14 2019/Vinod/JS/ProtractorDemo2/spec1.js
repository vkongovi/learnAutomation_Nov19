// npm init
// npm install  protractor
// npm  install   webdriver-manager
// webdriver-manager update
// webdriver-manager start


// in a  new console window run "protractor conf.js"


// All  test cases are written
//   Describe block => Test suite
//   IT block => Test  Case


//describe('Test Suite 1', function(){});

// describe('Name', function(){
//     it('Name', function(){

//     });
// });

describe('Test Suite 1', function(){
    it('Test Case 1',function(){
        browser.ignoreSynchronization = true;

        browser.get('https://www.google.com/');
        browser.manage().window().maximize();

        browser.sleep(2000);


    });
});
