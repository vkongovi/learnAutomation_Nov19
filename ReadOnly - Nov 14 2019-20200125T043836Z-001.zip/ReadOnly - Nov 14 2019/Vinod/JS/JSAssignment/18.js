function Employee(fName, lName, age, salary){
    this.firstName = fName;
    this.lastName = lName;
    this.age = age;
    this.salary = salary;
    }
    // Creating multiple object which have similar property but diff value assigned to object property.
    var employee1 = new Employee('John', 'Moto', 24, '5000$');
    var employee1 = new Employee('Ryan', 'Jor', 26, '3000$');
    var employee1 = new Employee('Andre', 'Salt', 26, '4000$');


    var employee = {
        name : 'Nishant',
        salary : 245678,
        }


        var employee = new Object(); // Created employee object using new keywords and Object()
        employee.name = 'Nishant';
        
        