function deepClone(object) {
    var newObject = {};
    for (var key in object) {
        if (typeof object[key] === 'object') {
            newObject[key] = deepClone(object[key]);
        } else {

            newObject[key] = object[key];
        }
    }
    return newObject;
}

var vin = { name: 'vinod', age: 35, friend: { name: 'vinod', age: 35 , owner:  {name: 'vinod', age: 35}} };
// var x = vin; // same reference
var x = deepClone(vin);
console.log(vin.name + '==' + x.name);
vin.name = 'kumar';
console.log(vin.name + '==' + x.name);



console.log('2' == 2);
console.log('2' === 2);


