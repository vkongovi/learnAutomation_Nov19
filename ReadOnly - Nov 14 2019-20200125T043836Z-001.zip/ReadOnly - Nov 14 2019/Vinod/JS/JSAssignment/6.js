var x = { foo: 1 , name:' vvinod'};
var output = (function () {
    delete x.foo;
    return x;
})();
console.log(output);