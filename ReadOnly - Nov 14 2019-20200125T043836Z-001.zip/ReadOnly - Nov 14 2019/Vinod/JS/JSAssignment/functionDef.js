var a  = (function(){
        console.log('Hi. I am Vinod');
})();

//a();

var b  = (10 + 20);
