function User(name) {
    this.name = name || "JsGeeks";
    }

    // var person = new User("xyz");
    // console.log(person instanceof User)
    
    var person = new User("xyz")["location"] = "USA";

    var z = new User();
    console.log(z);

    z["location"] = "usa";

    console.log(z);


    var  a = {name:'vinod'};
    a['age'] = 30;
    console.log(a);

    // var a = "sdafsa"  = 20;
    // console.log(a);
