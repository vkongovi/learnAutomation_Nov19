var salary = "1000$";
(function () {
//var  salary;
// local variable declared with same name as global var. So inside the func, local  will be used.
console.log("Original salary was " + salary);

var salary = "5000$";
console.log("My New Salary " + salary);
})();


// console.log(a);
// var a;