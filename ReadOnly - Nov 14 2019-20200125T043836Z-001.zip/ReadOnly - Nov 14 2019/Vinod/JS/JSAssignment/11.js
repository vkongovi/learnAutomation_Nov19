// var f =  function (){
//     return 10;
// }
// f();

// var a = function f(){
//     return 10;
// }
// f();

// console.log(typeof  func1());

var bar  = function bar(){ return 12;}
console.log(typeof  bar())
