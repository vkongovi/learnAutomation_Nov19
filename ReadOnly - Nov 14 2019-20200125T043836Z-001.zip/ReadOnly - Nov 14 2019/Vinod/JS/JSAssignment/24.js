var a = "abc";
var b = a/2;

console.log(typeof a)
console.log(typeof b)