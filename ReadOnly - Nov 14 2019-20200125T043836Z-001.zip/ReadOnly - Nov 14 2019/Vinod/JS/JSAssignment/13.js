var dog = new  String();
var a =  10;
console.log(a instanceof String);