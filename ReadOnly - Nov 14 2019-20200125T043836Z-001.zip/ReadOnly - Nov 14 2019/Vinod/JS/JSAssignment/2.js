var mul = function (z) { 
    return function (y) {
        return function (x) {
            return x * y * z ;
         }
    }
}

console.log(mul(2)(3)(5));