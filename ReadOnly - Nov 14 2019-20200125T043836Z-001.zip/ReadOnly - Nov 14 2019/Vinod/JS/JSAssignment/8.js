var trees = ["xyz", "xxxx", "test", "ryan", "apple"];
delete trees[3];
console.log(trees);