var person = {
    name: "Nishant",
    age : 24
    }
    

if(typeof person.salary === 'undefined'){
    console.log("salary is undefined here because we haven't declared");
}