var z = 1;
var y = 10; 
y = z = typeof y;
//var i =10,j;
console.log(y);

var a = 10  + 20;