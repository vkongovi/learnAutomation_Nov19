// JS 
//  ECMA  Script once every year 
// ES 2015/16

var i = 10;
let j = 10;
j = 'vinod';

// int i = 10; => Static data types ( in Java). Compilations
// var j = 110; => Dynamic binding of data type
j = 'Vinod';

// Primitivve  Data types
// String 
// number
// boolean 
// undefined 
// null 

// Referance Data types
// Object
// Array
// Function
//  objects
let obj =  { name: 'vinod', age: 35};
obj.name =  'Kumar';
obj['name'] = 'abc'

let p =  'name';
obj[p]='xyz';

console.log(obj);

// Arrays
let  v = ['red','blue'];
v[0]  = 'green';
v[2] = 'brown';
console.log(v) ;

function  abc(){
    console.log('abc called');
}
abc();

let sim = function(){
    console.log('i am inside the function');
}

sim();

let test1 =  5;
test1 = function(name){
        console.log('my name is ' + name);
    }

test1('vinod');



let x = 0;

let func1 = function(x){

}

func11(20);












