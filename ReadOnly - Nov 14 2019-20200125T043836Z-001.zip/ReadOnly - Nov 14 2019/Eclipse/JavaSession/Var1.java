
public class Var1 {
	
	int x;    // instance variable or Globle variable
	static int y;  // static variable
	
	void test()
	{
		int i=50;   // local variable
		System.out.println(i);
	}
	
	
	public static void main(String[] args) {
		Var1 v1=new Var1();    // object created
		int a=10;    // local variable
		System.out.println("The value of variable a is "+a);
		a=20;
		System.out.println("The value of variable a after re-initialization is "+a);
		
		System.out.println(v1.x);
		System.out.println(y);
		v1.test();
	}

}
