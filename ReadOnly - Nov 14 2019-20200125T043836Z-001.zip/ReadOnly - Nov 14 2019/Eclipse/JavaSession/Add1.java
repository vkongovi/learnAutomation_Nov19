
public class Add1 {
	
	// add two no.
	
	public static void main(String[] args) {
		
		int a=10;
		int b=20;
		int c=a+b;
		System.out.println("The sum of "+a+" & "+b+" is "+c);
		
	}

}
