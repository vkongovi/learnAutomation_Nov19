
public class A {

	/*
	 main(ctrl+space)
	 syso(ctrl+space)
	 */
	
	public static void main(String[] args) {
		System.out.println("Hello World!!");
	//	System.out.println(10);
	}

}
