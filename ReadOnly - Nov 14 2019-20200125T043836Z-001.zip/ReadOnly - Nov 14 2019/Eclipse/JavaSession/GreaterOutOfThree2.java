import java.util.Scanner;

// WJP to find first, second and third big out of three no.

public class GreaterOutOfThree2 {
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the value of a: ");
		int a=sc.nextInt();
		System.out.println("Enter the value of b: ");
		int b=sc.nextInt();
		System.out.println("Enter the value of c: ");
		int c=sc.nextInt();
		if(a>b && a>c)
		{
			System.out.println(a+" is first big");
			if(b>c)
			{
				System.out.println(b+" is second big");
				System.out.println(c+" is third big");
			}
			else
			{
				System.out.println(c+" is second big");
				System.out.println(b+" is third big");
			}
			
		}
		else if(b>c)
		{
			System.out.println(b+" is first big");
			if(a>c)
			{
				System.out.println(a+" is second big");
				System.out.println(c+" is third big");
			}
			else
			{
				System.out.println(c+" is second big");
				System.out.println(a+" is third big");
			}
		}
		else
		{
			System.out.println(c+" is first big");
			if(a>b)
			{
				System.out.println(a+" is second big");
				System.out.println(b+" is third big");
			}
			else
			{
				System.out.println(b+" is second big");
				System.out.println(a+" is third big");
			}
		}
		
	}

}
