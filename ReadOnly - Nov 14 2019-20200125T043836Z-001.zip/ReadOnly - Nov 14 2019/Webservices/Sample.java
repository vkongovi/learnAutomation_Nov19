import org.testng.annotations.Test;
import static com.jayway.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import com.jayway.restassured.path.json.JsonPath;

public class Sample {
	
	@Test
	public void getStates() {
		
		//Dependencies - rest-assured, hamcrest, Jackson-databind and TestNG
		
//		given()
//		 - Requestbody
//		 - Parameters
//		 - headers
//		 - authorization
//		when()
//		 - GET,POST, PUT or DELETE
//		then()
//		-Validation - status codes , response body
		
		given()
		.pathParam("landlordID", "AQGIvagU")
		//.queryParam("text", "Uttar Pradesh")
		//.formParam("Username", "sushma", "Password","sushma123")
		//.auth().basic("UN", "PWD")
		//.header(arg0)
		
		.when()
		//.get("http://localhost:8080/landlords/{landlordID}")
		.get("http://localhost:8080/landlords/{landlordID}")
		.then()
		.statusCode(200)
		.body("id", is("AQGIvagU"))
		.body("id", isOneOf("AQGIvagU", "AQGIabgU"))
		.extract().response().prettyPrint();
		
		
	}

}
